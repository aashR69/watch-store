const signUp = (e) =>{
    e.preventDefault()

    fetch("http://127.0.0.1:8000/signUp/", {
    method: "POST",
    body: JSON.stringify({
        name: e.target.name.value,
        username: e.target.username.value,
        password: e.target.passw.value
    }),
    headers: {
        "Content-type": "application/json; charset=UTF-8"
    }

}).then(alert('Sign Up Successful !'))


}



