
let addData = (cls) =>{

    const item = localStorage.getItem('username');

    if(item){
        console.log('Name exists');
    }else{
        console.log('Name is not found');
        alert("Please Login to add item to Cart")
        return
    }

    cls = document.getElementsByClassName(cls)[0];

    let model = cls.children[2].children[0].innerText;
    let price = parseInt(cls.children[2].children[1].innerText.slice(4));
    let image = cls.children[1].src;
    let amount = 1;
 
    let box = document.getElementsByClassName('cart__container')[0]

    let html = `<article class="cart__card" id = "${model}" >
                    <div class="cart__box">
                        <img src="${image}" alt="" class="cart__img">
                    </div>
                    
                    <div class="cart__details">
                        <h3 class="cart__title">${model}</h3>
                        <span class="cart__price">Rs/-${price}</span>
                    
                        <div class="cart__amount">
                            <div class="cart__amount-content">
                                <span class="cart__amount-box">
                                    <i onclick = "decrease('${model}')" class='bx bx-minus' ></i>
                                </span>
                    
                                <span class="cart__amount-number-${model}">${amount}</span>
                    
                                <span class="cart__amount-box">
                                    <i onclick = "increase('${model}')" class='bx bx-plus' ></i>
                                </span>
                            </div>
                    
                            <i onclick = "deleteData('${model}')" class='bx bx-trash-alt cart__amount-trash' ></i>
                        </div>
                    </div>
                </article>`
    
    box.insertAdjacentHTML('afterend',html);


    let val = document.getElementsByClassName('cart__prices-total')[0].innerText;
    if(val==''){
        localStorage.setItem('grandval',price);
        document.getElementsByClassName('cart__prices-total')[0].innerText = "Grand Total : Rs/-" + price;
    }
    else{
        const newVal = parseInt(val.slice(18))+parseInt(price);
        localStorage.setItem('grandval',newVal);
        document.getElementsByClassName('cart__prices-total')[0].innerText =  "Grand Total : Rs/-" + newVal ;

    }


}

let increase = (model) => {

    document.getElementsByClassName(`cart__amount-number-${model}`)[0].innerText = 2

}

let decrease = (model) => {

    document.getElementsByClassName(`cart__amount-number-${model}`)[0].innerText = 0

}

let deleteData = (model) =>{

    document.getElementById(model).remove()

}


let checkOut = () =>{

    let data = document.getElementsByClassName('cart__card');

    let cart = [];

    for (var i = 0; i < data.length; i++) {

        cart.push({name:data[i].children[1].children[0].innerText,
            price:data[i].children[1].children[1].innerText.slice(4),
            image: data[i].children[0].children[0].src})
        
    }

    localStorage.setItem('cart', JSON.stringify(cart ) )
    self.location="checkout.html";
    

}