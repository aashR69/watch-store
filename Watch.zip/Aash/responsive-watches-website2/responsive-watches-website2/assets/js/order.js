console.log('hi')

const sendOrder = (e) =>{

    e.preventDefault();

    // console.log(e.target.state.value);

    fetch("http://127.0.0.1:8000/order/", {
    method: "POST",
    body: JSON.stringify({
        user : localStorage.getItem('username'),
        email: e.target.email.value,
        address : e.target.address.value,
        state : e.target.state.value,
        city : e.target.city.value,
        zip : e.target.zip.value,
        data : localStorage.getItem('cart')

    }),
    headers: {
        "Content-type": "application/json; charset=UTF-8"
    }

}).then(res=>res.json()).then(user =>{

    alert("thanks for shopping !")
    console.log(user)
    
    })

}