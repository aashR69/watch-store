const login = (e) =>{
    e.preventDefault()

    fetch("http://127.0.0.1:8000/login/", {
    method: "POST",
    body: JSON.stringify({
        username: e.target.username.value,
        password: e.target.password.value
    }),
    headers: {
        "Content-type": "application/json; charset=UTF-8"
    }

}).then(res=>res.json()).then(user =>{
    
    console.log(user)
    if(user.response!=400){
        alert(`welcome ${user.name} `)
        window.location.href = "index.html";
        localStorage.setItem('name',user.name);
        localStorage.setItem('username',user.username);


    }else{
        alert("Invalid Login !")
    }


    })


}
