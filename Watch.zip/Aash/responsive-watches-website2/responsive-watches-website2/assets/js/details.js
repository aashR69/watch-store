
function showDetails(cls){

    cls = document.getElementsByClassName(cls)[0];
    // console.log(cls.children[2].children[1].innerText)
    // localStorage.setItem('class', cls)


    localStorage.setItem('name', cls.children[2].children[0].innerText)
    localStorage.setItem('amount', cls.children[2].children[1].innerText)
    localStorage.setItem('image', cls.children[1].src)
    self.location="detail.html";

    


}


document.getElementsByClassName('story__title')[0].innerText = localStorage.getItem('name')
document.getElementsByClassName('story__img')[0].src = localStorage.getItem('image')
    
document.getElementsByClassName('section__title story__section-title')[0].innerText = "$"+localStorage.getItem('amount')

let classData = localStorage.getItem('class')

console.log(classData)
