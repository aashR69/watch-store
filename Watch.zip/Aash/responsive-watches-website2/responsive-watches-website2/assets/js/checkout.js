let dib = document.getElementById('box');
console.log(dib)
let mydata = JSON.parse(localStorage.getItem("cart") || "[]");



mydata.forEach(element => {

        let code = `<article class="cart__card"  >
        <div class="cart__box">
            <img src="${element.image}" alt="" class="cart__img">
        </div>
        
        <div class="cart__details">
            <h3 class="cart__title">${element.name}</h3>
            <span class="cart__price">Rs/-${element.price}</span>
        
            <div class="cart__amount">
                
            </div>
        </div>
    </article>`

        dib.insertAdjacentHTML('afterend',code);

});

let total = document.getElementById('box');

total.innerText = "Rs/- " +localStorage.getItem('grandval')


console.log(localStorage.getItem('grandval'))