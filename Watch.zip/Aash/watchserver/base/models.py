from django.db import models

class User(models.Model):
    name = models.TextField(max_length = 30)
    username = models.TextField(max_length = 10)
    password = models.TextField(default=10)

    def __str__(self):
        return self.name

class User_Detail(models.Model):
    user = models.ForeignKey(User,on_delete= models.CASCADE)
    email = models.TextField(max_length=10)
    address = models.TextField(max_length=30)
    state = models.TextField(max_length=10)
    city = models.TextField(max_length=10)
    zipcode = models.TextField(max_length=10)

    def __str__(self):
        return self.user.name

class Item(models.Model):
    user = models.ForeignKey(User,on_delete= models.CASCADE)
    name = models.TextField(max_length=10)
    price = models.IntegerField()



