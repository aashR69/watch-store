from django.urls import path
from .views import *



urlpatterns =[
	
	path('',getData),
    path('signUp/',signup,name='signUpUser'),
    path('login/',login),
    path('order/',order),
	
]