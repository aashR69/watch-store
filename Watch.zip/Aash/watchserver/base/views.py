from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import User,User_Detail,Item
from django.http import HttpResponse,JsonResponse

@api_view(['GET'])
def getData(request):

    return Response({'name':"carl"})

@api_view(['POST'])
def signup(request):
	name = request.data['name']
	username = request.data['username']
	password = request.data['password']

	if User.objects.filter(username=username).exists():
		return JsonResponse({'repsonse':'error'},safe=False)

	user = User.objects.create(name=name,username=username,password= password)
	user.save()

	return JsonResponse({'repsonse':'success'},safe=False)

@api_view(['POST'])
def login(request):
    username = request.data['username']
    password = request.data['password']

    if User.objects.filter(username=username,password=password).exists():
        user = User.objects.get(username=username)
        return JsonResponse({'name':user.name,'username':username},safe=False)


    return Response({'response':400})


@api_view(['POST'])
def order(request):
    user = User.objects.get(username=request.data['user'])
    
    data = User_Detail.objects.create(
        user =user,
        email = request.data['email'],
        address = request.data['address'],
        state = request.data['state'],
        city = request.data['city'],
        zipcode = request.data['zip']    
    )
    data.save()

    items = eval(request.data['data'])

    for item in items:
        temp = Item.objects.create(
            user = user,
            name = item['name'],
            price = item['price']
        )
        temp.save()

    print(items[0]['name'])

    return Response({'response':400})